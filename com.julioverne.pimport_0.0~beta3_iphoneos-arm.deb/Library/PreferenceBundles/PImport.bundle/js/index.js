/*
 Copyright (c) 2012-2015, Pierre-Olivier Latour
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * The name of Pierre-Olivier Latour may not be used to endorse
 or promote products derived from this software without specific
 prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL PIERRE-OLIVIER LATOUR BE LIABLE FOR ANY
 DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

var ENTER_KEYCODE = 13;

var $document = $(document);

var _path = "/";
var _data = [];
var _contentSort = "sortByNameAsc";
var _optionsPopoverPath = null;
var _last_optionsPopoverPath = null;
var _pendingReloads = [];
var _reloadingDisabled = 0;
var _paths_selected = [];
var _last_paths_selected = null;
var _dropZonePath = null;
var _webSocket = null;
var _tab_close_confirmation = true;
var _shortKeysAdded = false;
var _open_url_on_server_did_stop = null;
        
var _isIE11 = !!window.MSInputMethodContext && !!document.documentMode;

var _isSafari = navigator.vendor && navigator.vendor.indexOf('Apple') > -1 &&
                   navigator.userAgent && !navigator.userAgent.match('CriOS');

function disableReloads() {
    _reloadingDisabled += 1;
}

function enableReloads() {
    _reloadingDisabled -= 1;
    if (_pendingReloads.length > 0) {
        reloadWithPath(_pendingReloads.shift());
    }
}

function reload() {
    reloadWithPath(_path);
}

function reloadWithPath(path) {
    
    path = decodeURIComponent(path) || "/";

    if (_reloadingDisabled) {
        if ($.inArray(path, _pendingReloads) < 0) {
            _pendingReloads.push(path);
        }
        return;
    }

    disableReloads();

    deselectAllCells();

    $.ajax({
       cache: false,
        url: 'rdwifidrive/list',
        type: 'GET',
        data: {path: path, sort: _contentSort},
        beforeSend: function(request) {
            request.setRequestHeader("Session-Id", getSID());
        },
        dataType: 'json'
    }).fail(function (jqXHR, textStatus, errorThrown) {
        showError("Falha a obter o conteúdo no caminho \"" + path + "\"", textStatus, errorThrown);
        renderBreadcrumb(path);
        if(jqXHR.status===401){
            startPinCodeAuth();
        }
    }).done(function (data, textStatus, jqXHR) {
        
        var scrollPosition = $document.scrollTop();
        
        _path = path;
        _data = data;
        
        renderBreadcrumb(path);

        updateCurrentLayoutVisibility();

        createCellsWithData(data);
        
        updateHeaderActions();
        
        updateOptionsCtrl();

        updateCellActions();
        
        disableDragStartEventForCellIcon();

        updateCellContextMenu();

        addShortKeys();
        
        updateShortKeys();
        
        $document.scrollTop(scrollPosition);
        
        updateEcho();
        
        updateWebSocketIfNull();
        
        initPopovers();

    }).always(function () {
        enableReloads();
    });
}

//https://makandracards.com/makandra/5885-flexible-overflow-handling-with-css-and-javascript
function updateVisibilityForRowActions(row,visible){

    var title = row.find('.column-name__text');
    var actions = row.find('.column-name__actions');
    var containerWidth = row.width();  
    
    if(visible===true){
        actions.removeClass('hidden');
        title.css('text-overflow', 'ellipsis');
        title.css('overflow', 'hidden');
        $.each([ title, actions ], function(index, self) {
            $(self).css('float', 'left');
            $(self).css('white-space', 'nowrap');
        });
        var actionsWidth = actions.outerWidth();
        title.css('max-width', (containerWidth - actionsWidth) + 'px');
    }
    else{
        actions.addClass('hidden');
        title.css('max-width', containerWidth + 'px');
    }
}

//clear selected items array and update table rows state
function deselectAllCells() {

    //clear selected items array
    _paths_selected.splice(0, _paths_selected.length);

    updateHeaderActions();
    updateOptionsCtrl();

    //deselect all cells
    if(isGridLayout()){
        $(".thumbnail").removeClass('selected');
    }
    else{
        $(".row-file").removeClass('selected');
    }

    //deselect all checkboxes
    var $chkbox_all = null;
    var $chkbox_select_all = null;
    
    if(isGridLayout()){
        var $list = $("#gallery");
        $chkbox_all = $('.thumbnail input[type="checkbox"]', $list);
        $chkbox_select_all = $('#gridheader input[type="checkbox"]');
    }
    else{
        var $table = $("#filestable");
        $chkbox_all = $('tbody input[type="checkbox"]', $table);
        $chkbox_select_all = $('thead input[type="checkbox"]', $table);
    }

    $chkbox_all.each(function () {
        $(this).prop('checked', false);
        $(this).prop('indeterminate', false);
    });

    //uncheck 'select all' checkbox
    $chkbox_select_all.each(function () {
        $(this).prop('checked', false);
        $(this).prop('indeterminate', false);
    });

}

//select all items and update table rows selected state
function selectAllCells() {
    //clear selected paths array
    _paths_selected.splice(0, _paths_selected.length);
    //fill selected items array
    if(_data.length>=2){
        for (var i = 1, file; file = _data[i]; ++i) {
            _paths_selected.push(file.path);
        }
    }
    updateHeaderActions();
    updateOptionsCtrl();
    //select all cells
    if(isGridLayout()){
        $(".thumbnail").addClass('selected');
    }
    else{
        $(".row-file").addClass('selected');
    }
    //select checkboxes for table rows
    var $chkbox_all = null;
    var $chkbox_select_all = null;
    if(isGridLayout()){
        var $gallery = $("#gallery");
        $chkbox_all = $('.thumbnail input[type="checkbox"]', $gallery);
        $chkbox_select_all = $('#gridheader input[type="checkbox"]');
    }
    else{
        var $table = $("#filestable");
        $chkbox_all = $('tbody input[type="checkbox"]', $table);
        $chkbox_select_all = $('thead input[type="checkbox"]', $table);
    }
    
    $chkbox_all.each(function () {
        $(this).prop('checked', true);
        $(this).prop('indeterminate', false);
    });

    //uncheck 'select all' checkbox
    $chkbox_select_all.each(function () {
        $(this).prop('checked', true);
        $(this).prop('indeterminate', false);
    });

}

function selectTableRow(selectedRow){
    var $row = selectedRow;
    var $checkbox = $row.find("input[type=checkbox]");
    var rowId = $row.data("path");
    var index = $.inArray(rowId, _paths_selected);
    if (index === -1) {
        _paths_selected.push(rowId);
        $checkbox.prop("checked", true);
        $row.addClass('selected');
        updateSelectAllCtrl();
        updateHeaderActions();
        updateOptionsCtrl();
    } 
}

function selectedPathsLength(){
    var paths_selected_count = 0;
    if(_paths_selected!==null && _paths_selected.length>0){
        paths_selected_count = _paths_selected.length;
    }
    return paths_selected_count;
}

function deselectTableRow(selectedRow){
    var $row = selectedRow;
    var $checkbox = $row.find("input[type=checkbox]");
    var rowId = $row.data("path");
    var index = $.inArray(rowId, _paths_selected);
    if (index !== -1){
        _paths_selected.splice(index, 1);
        $checkbox.prop("checked", false);
        $row.removeClass('selected');
        updateSelectAllCtrl();
        updateHeaderActions();
        updateOptionsCtrl();
    }
}

function createCellsWithData(data) {
    if(data.length>0){
        
        //header data
        var dataOptions = data[0];

        if(isGridLayout()){
            $(tmpl("template-grid-header", dataOptions)).data(dataOptions).appendTo("#gridheader");
        }
        else{
            $(tmpl("template-header", dataOptions)).data(dataOptions).appendTo("#tableheader");
        }

        //cells data
        for (var i = 1, file; file = data[i]; ++i) {
            if(isGridLayout()){
                $(tmpl("template-thumbnail", file)).data(file).find(".thumbnail").data(file).end().appendTo("#gallery");
            }
            else{
                $(tmpl("template-listing", file)).data(file).appendTo("#listing");
            }
        }

        //hide placeholder
        DomUtils.hideElement($("#filestable-no-data-placeholder-id"));
    }
    else{
        //show placeholder
        DomUtils.showElement($("#filestable-no-data-placeholder-id"));
    }
}

function updateCurrentLayoutVisibility() {
  if(isGridLayout()){
        $("#gridheader").empty();
        $("#gallery").empty();
        DomUtils.hideElement($("#filestable"));
        DomUtils.showElement($("#gridheader"));
        DomUtils.showElement($("#gallery"));
    }
    else{
        $("#tableheader").empty();
        $("#listing").empty();
        DomUtils.showElement($("#filestable"));
        DomUtils.hideElement($("#gridheader"));
        DomUtils.hideElement($("#gallery"));
    }
}

// Updates controls in table header
function updateHeaderActions() {
    var array = _paths_selected;
    var arrayLength = array.length;
    if (arrayLength > 0) {
        DomUtils.showElement($("#btn-multi-download-id"));
        DomUtils.showElement($("#btn-multi-delete-id"));
        $("#btn-create-folder-id").addClass('disabled');
    }
    else {
        DomUtils.hideElement($("#btn-multi-download-id"));
        DomUtils.hideElement($("#btn-multi-delete-id"));
        $("#btn-create-folder-id").removeClass('disabled');
    }    
}

function disableDragStartEventForCellIcon() {
    //disable drag start event for cell icon
    $(".btn-file-icon").on('dragstart', function () {
         return false;
    });
}

function updateCellContextMenu() {
    
    $(".row-file").contextmenu(function (event) {
        var $row = $(this);
        log.log("row-file.contextmenu: " + $row);
        updateVisibilityForRowActions($row,false);
        $row.find(".button-cell-contextmenu").click();
        event.preventDefault();
        centerPopover(event);
    });        

    $(".button-cell-contextmenu").click(function (event) {
        log.log("button-cell-contextmenu.click");

        var $elem = $(this);

        var title = "";  
        var icon = ""; 
        var iconClass = "";

        //deselect all files on popover dismiss if we selected files with right click
        //and no files were selected before
        if(_paths_selected!==null && _paths_selected.length===0){
            setShouldDeselectAllFilesOnPopoverDismiss();
        }
        else{
            clearShouldDeselectAllFilesOnPopoverDismiss();
        }
        //select clicked row
        var _paths_selected_count = selectedPathsLength();
        var $row = DomUtils.getClosestRow($elem);
        selectTableRow($row);
        var _paths_selected_count_updated = selectedPathsLength();

        if(_paths_selected.length>1){
           title = "Selecionados: "+_paths_selected.length;
           iconClass =  "list-heading-icon-large";
           if(_paths_selected.length===2){
              icon = "../images/items-selected-2.png";
           }
           else {
              icon = "../images/items-selected-3.png";
           }

           //update rename action state
           $("#action-rename-multiple-id").addClass('disabled');
           $("#span-rename-multiple-id").addClass('disabled');
           $("#img-rename-multiple-id").attr("src","../images/options-rename-dis.png");

        } 
        else{

            var path = _paths_selected[0];
            var name = path;
            if (name[name.length - 1] === "/") {
                name = name.slice(0, name.length - 1);
            }
            name = name.substr(name.lastIndexOf('/') + 1);
            title = name;
            icon = "/fileicons?path=" + encodeURIComponent(path) + "";
            iconClass =  "list-heading-icon";

            //update rename action state
            $("#action-rename-multiple-id").removeClass('disabled');
            $("#span-rename-multiple-id").removeClass('disabled');
            $("#img-rename-multiple-id").attr("src","../images/options-rename.png");

        }

        //update popover title     
        $("#popover-contextmenu-title-id").text(title);

        //update popover icon
        $("#popover-contextmenu-img-id").attr("src",icon);
        $("#popover-contextmenu-img-id").removeClass('list-heading-icon');
        $("#popover-contextmenu-img-id").removeClass('list-heading-icon-large');
        $("#popover-contextmenu-img-id").addClass(iconClass);

        event.stopPropagation();

        //show popover only if selected paths were updated
        if(_paths_selected_count_updated!==_paths_selected_count || isCurrentPopoverTargetActive()===false){
            showDefaultPopoverForTarget($(event.target));
        }

    });
}

function updateCellActions() {
    function openFile(event) {
        hideAllPopovers();
        var $elem = $(this);
        var path = DomUtils.getClosestRow($elem).data("path");
        if (path) {
            setTimeout(function () {
               openInNewTabURL("rdwifidrive/open?sid="+getSID()+"&path=" + encodeURIComponent(path));
            }, 0);
            event.stopPropagation();
        }
    }

    function openFolder(event) {
        hideAllPopovers();
        var $elem = $(this);
        var path = DomUtils.getClosestRow($elem).data("path");
        window.location.hash = "#" + encodeURIComponent(path);
        event.stopPropagation();
    }

    $(".button-cell-download").click(openFile);
    $(".file-name").click(openFile);
    $(".button-cell-open").click(openFolder);
    $(".folder-name").click(openFolder);
    
    $(".button-cell-delete").click(function (event) {
        var $elem = $(this);
        var path = DomUtils.getClosestRow($elem).data("path");
        hideAllPopovers();
        $.ajax({
           cache: false,
            url: 'rdwifidrive/delete',
            type: 'GET',
            data: {path: path},
            beforeSend: function(request) {
                request.setRequestHeader("Session-Id", getSID());
            },
            dataType: 'json'
        }).fail(function (jqXHR, textStatus, errorThrown) {
            showError("Falhar ao apagar \"" + path + "\"", textStatus, errorThrown);
        }).done(function () {
            reloadWithPath(_path);
        });
        event.stopPropagation();
    });  
    
    
    $(".button-cell-options").click(function (event) {
            
        var $elem = $(this);
        var currentOptionsPopoverPath = _optionsPopoverPath;
        var path = null;

        if(isGridLayout()){
            path = DomUtils.getClosestThumbnail($elem).parent().data("path");
        }
        else{
            path = DomUtils.getClosestRow($elem).data("path");
        }

        var name = path;
        if (name[name.length - 1] == "/") {
            name = name.slice(0, name.length - 1);
        }
        name = name.substr(name.lastIndexOf('/') + 1);
        var ext = name.substr(name.lastIndexOf('.') + 1).toLowerCase();

        log.log("button-cell-options.click: " + path);

        //update popover title
        $("#popover-options-title-id").text(name);

        //update popover icon
        $("#popover-options-img-id").attr("src","/fileicons?path=" + encodeURIComponent(path) + "");

        _optionsPopoverPath = path;

        //Prevent click event from propagating to parent so table cell selection will not trigger
        event.stopPropagation();

        if(currentOptionsPopoverPath!==_optionsPopoverPath){
            showDefaultPopoverForTarget($(event.target));
        }
        else{
            hideAllPopovers();
        }
        
    });
    
 
    //show actions on title hover
    $(".column-name").hover(
        function(){ 
            if(_paths_selected.length===0){
                updateVisibilityForRowActions($(this),true);
            }
        },
        function(){ 
            updateVisibilityForRowActions($(this),false);
        }
    ); 

    //show popover on single action hover
    $(".btn-single-download").hover(
        function(){ 
            showTooltipPopoverForTarget($(this));
        },
        function(){ 
            hideCurrentPopover();
        }
    );

    $(".btn-single-rename").hover(
        function(){ 
            showTooltipPopoverForTarget($(this));
        },
        function(){ 
            hideCurrentPopover();
        }
    );

    $(".btn-single-delete").hover(
        function(){ 
            showTooltipPopoverForTarget($(this));
        },
        function(){ 
            hideCurrentPopover();
        }
    );

    $(".btn-single-download").click(function (event) {
        var $elem = $(this);
        var $row = DomUtils.getClosestRow($elem);
        var path = $row.data("path");
        downloadItemAtPath(path);
    });

    $(".btn-single-delete").click(function (event) {
        var $elem = $(this);
        var $row = DomUtils.getClosestRow($elem);
        var path = $row.data("path");
        deleteItemAtPath(path);
    });

    $(".btn-single-rename").click(function (event) {
        var $elem = $(this);
        var $row = DomUtils.getClosestRow($elem);
        var path = $row.data("path");
        renameItemAtPath(path);
    });

    $(".thumbnail button.btn-file-icon").hover(
        function(e) {
            DomUtils.getClosestThumbnail($(this)).find(".item-info .item-name").addClass("hover");
        },
        function(e) {
            DomUtils.getClosestThumbnail($(this)).find(".item-info .item-name").removeClass("hover");
        }
    );
    $("img[data-echo]").error(imageNotFound);

}

function updateShortKeys(){
    $(document).on('show.bs.modal', function() {
        removeShortKeys();
    });

    $(document).on('hide.bs.modal', function() {
        addShortKeys();
    });
}

function addShortKeys() {
    if(_shortKeysAdded===false){
        shortcut.add("ctrl+a", function() {
           selectAllCells();
        });
        shortcut.add("meta+a", function() {
           selectAllCells();
        });
        shortcut.add("delete", function() {
            if(_paths_selected!==null && _paths_selected.length>0){
                actionMultipleDelete();
            }
        });
        _shortKeysAdded = true;
    }
}

function removeShortKeys() {
    if(_shortKeysAdded===true){
        shortcut.remove("ctrl+a");
        shortcut.remove("meta+a");
        shortcut.remove("delete");
        _shortKeysAdded = false;
    }
}

// Updates "..." control for all cells in table
function updateOptionsCtrl() {
    var array = _paths_selected;
    var arrayLength = array.length;
    var $options_ctrl_all = null;
    
    if(isGridLayout()){
        var $list = $("#gallery");
        $options_ctrl_all = $('.thumbnail .button-cell-options', $list);
    }
    else{
        var $table = $("#filestable");
        $options_ctrl_all = $('tbody tr td .button-cell-options', $table);
    }
    
    if (arrayLength > 0) {
        $('.button-cell-options').each(function() {
            //$(this).prop('disabled', true);
            $(this).addClass('disabled');
        });
    }
    else {
        $('.button-cell-options').each(function() {
            //$(this).prop('disabled', false);
            $(this).removeClass('disabled');
        });
    }
}

// Updates "Select all" control in a data table
function updateSelectAllCtrl() {

    var $chkbox_all = null;
    var $chkbox_checked = null;
    var chkbox_select_all = null;
    
    if(isGridLayout()){
        var $list = $("#gallery");
        $chkbox_all = $('.thumbnail input[type="checkbox"]', $list);
        $chkbox_checked = $('.thumbnail input[type="checkbox"]:checked', $list);
        chkbox_select_all = $('#gridheader input[type="checkbox"]').get(0);
    }
    else{
        var $table = $("#filestable");
        $chkbox_all = $('tbody input[type="checkbox"]', $table);
        $chkbox_checked = $('tbody input[type="checkbox"]:checked', $table);
        chkbox_select_all = $('thead input[type="checkbox"]', $table).get(0);
    }

    // If none of the checkboxes are checked
    if ($chkbox_checked.length === 0) {
        chkbox_select_all.checked = false;
        if ('indeterminate' in chkbox_select_all) {
            chkbox_select_all.indeterminate = false;
        }
    // If all of the checkboxes are checked
    } else if ($chkbox_checked.length === $chkbox_all.length) {
        chkbox_select_all.checked = true;
        if ('indeterminate' in chkbox_select_all) {
            chkbox_select_all.indeterminate = false;
        }

    // If some of the checkboxes are checked
    } else {
        chkbox_select_all.checked = true;
        if ('indeterminate' in chkbox_select_all) {
            chkbox_select_all.indeterminate = true;
        }
    }
}


function updateEcho() {
    echo.init({
            offset: 100,
            throttle: 250,
            unload: false,
            callback: function (element, op) {
                  console.log(element, 'has been', op + 'ed')
            }
    });
}

$document.ready(function () {
    
    if (!_isIE11) {
        document.documentElement.classList.add("good-browser");
    }

    updateSID();

    initUpload();
    
    initArchivePanel();
    
    initDeletePanel();
    
    initPopovers();

    updateEcho();
              
    $("#create-input").keypress(function (event) {
        if (event.keyCode === ENTER_KEYCODE) {
            $("#create-confirm").click();
        }
    });

    $("#create-modal").on("shown.bs.modal", function (event) {
        $("#create-input").focus();
        $("#create-input").select();
    });

    $("#btn-create-folder-id").click(function (event) {
        actionCreateFolder();
    });

    $("#btn-multi-download-id").click(function (event) {
        if ($(this).hasClass("disabled")) {
            return false;
        }
        actionMultipleDownload();
    });

    $("#btn-multi-delete-id").click(function (event) {
        if ($(this).hasClass("disabled")) {
            return false;
        }
        actionMultipleDelete();
    });

    $("#create-confirm").click(function (event) {
        $("#create-modal").modal("hide");
        var name = $("#create-input").val();
        if (name !== "") {
            $.ajax({
               cache: false,
                url: 'rdwifidrive/create',
                type: 'GET',
                data: {path: _path + name},
                beforeSend: function(request) {
                    request.setRequestHeader("Session-Id", getSID());
                },
                dataType: 'json'
            }).fail(function (jqXHR, textStatus, errorThrown) {
                showError("Falha ao criar a pasta. \"" + name + "\"", textStatus, errorThrown);
            }).done(function () {
                reloadWithPath(_path);
            });
        }
    });

    $("#move-input").keypress(function (event) {
        if (event.keyCode === ENTER_KEYCODE) {
            $("#move-confirm").click();
        }
    });

    $("#move-modal").on("shown.bs.modal", function (event) {
        $("#move-input").focus();
        var name = $("#move-input").val();
        var selectionIndex = name.lastIndexOf(".");
        if(selectionIndex===-1){
            selectionIndex = name.length;
        }
        var input = document.getElementById("move-input");
        input.setSelectionRange(0,selectionIndex);
    });

    $("#move-confirm").click(function (event) {
        $("#move-modal").modal("hide");
        var oldPath = $("#move-input").data("path");
        var parentPath = oldPath.substr(0, oldPath.lastIndexOf('/'));
        var newName = $("#move-input").val();
        var newPath = parentPath.concat("/", newName);
        var oldName = oldPath.substr(oldPath.lastIndexOf('/') + 1);

        if ((newName !== "") && (newPath !== oldPath)) {
            $.ajax({
               cache: false,
                url: 'rdwifidrive/move',
                type: 'GET',
                data: {oldPath: oldPath, newPath: newPath},
                beforeSend: function(request) {
                    request.setRequestHeader("Session-Id", getSID());
                },
                dataType: 'json'
            }).fail(function (jqXHR, textStatus, errorThrown) {
                showError("Falha ao renomear \"" + oldName + "\" to \"" + newName + "\"", textStatus, errorThrown);
            }).done(function () {
                reloadWithPath(_path);
            });
        }
    });
    
    $("#close-session").click(function (event) {
        sendWebCommand("STOP_SERVER");
        if(_open_url_on_server_did_stop!==null){
           window.location = _open_url_on_server_did_stop;
        }
        else{
            showConnectionClosed();
        }
    });  
    
    // Handle click on grid item checkbox
    $("#gallery").on('click', 'input[type="checkbox"]', function (e) {
        hideAllPopovers();
        var $elem = $(this);
        var $row = $elem.closest('.thumbnail');
        var table = $("#gallery");
        var rowId = DomUtils.getClosestThumbnail($elem).parent().data("path");

        log.log("gallery-checkbox.click: " + rowId);
        var index = $.inArray(rowId, _paths_selected);
        if ($elem.prop("checked") ) {
            _paths_selected.push(rowId);
            $row.addClass('selected');
        } else {
            _paths_selected.splice(index, 1);
            $row.removeClass('selected');
        }
        updateSelectAllCtrl();
        updateHeaderActions();
        updateOptionsCtrl();
        e.stopPropagation();
    });

    $("#gridheader").on('click', 'input[type="checkbox"]', function (e) {
        hideAllPopovers();
        if (this.checked) {
            selectAllCells();
        } else {
            deselectAllCells();
        }
        e.stopPropagation();
    });

    // Handle click on table row checkbox
    $("#filestable tbody").on('click', 'input[type="checkbox"]', function (e) {
        hideAllPopovers();
        var $elem = $(this);
        var $row = $elem.closest('tr');
        var table = $("#filestable");
        var rowId = DomUtils.getClosestRow($elem).data("path");

        log.log("filestable-checkbox.click: " + rowId);
        var index = $.inArray(rowId, _paths_selected);
        if (index === -1) {
            _paths_selected.push(rowId);
            $row.addClass('selected');
        } else if (index !== -1) {
            _paths_selected.splice(index, 1);
            $row.removeClass('selected');
        }
        updateSelectAllCtrl();
        updateHeaderActions();
        updateOptionsCtrl();
        e.stopPropagation();
    });

    // Handle click on select all checkbox
    $("#filestable thead").on('click', 'input[type="checkbox"]', function (e) {
        hideAllPopovers();
        if (this.checked) {
            selectAllCells();
        } else {
            deselectAllCells();
        }
        e.stopPropagation();
    });
    

    $document.on('click', function (e) {
        //log.log("$document.click: " + e + " this: "+ $(this) + " target: " + e.target);
    });

    $('html').on('click', function(e) {
       //log.log("html.click: " + e + " this: "+ $(this) + " target: " + e.target);
       hideAllPopovers();
    });
    
    //popover did show 
    $(document).on('shown.bs.popover', function (ev) {
      log.log("shown.bs.popover");
    });

    //popover dismiss
    $(document).on('hidden.bs.popover', function (ev) {
      log.log("hidden.bs.popover");  
    });

    $("#reload").click(function () {
        reloadWithPath(_path);
    });
    
    var locationHash = window.location.hash.replace("#", "");
    if (locationHash) {
        reloadWithPath(locationHash);
    } else {
        reloadWithPath("/");
    }

    $(window).bind("hashchange", function () {
        reloadWithPath(window.location.hash.replace("#", ""));
    });
    
    $(window).bind("unload", function() { 
        log.log("window unload");
        sendWebCommand("WINDOW_UNLOAD");
    });

    updateWebSocket();
    
});


function openURLOnServerDidStop() {
    if(_open_url_on_server_did_stop!==null){
        window.location = _open_url_on_server_did_stop;
        return true;
    }
    return false;
}

function openInNewTabURL(url) {
    var win = window.open(url, '_blank');
    win.focus();
}

function openInCurrentTabURL(url) {
    window.location = url;
}

function imageNotFound() {
    var $this = $(this);
    $this.attr('src', $this.attr('data-echo-icon') );
	$this.addClass('item-icon-shown');
    $this.off();
}

function hideAllModals(){
    $('.modal').modal('hide'); // closes all active pop ups.
    $('.modal-backdrop').remove(); // removes the grey overlay.
}

