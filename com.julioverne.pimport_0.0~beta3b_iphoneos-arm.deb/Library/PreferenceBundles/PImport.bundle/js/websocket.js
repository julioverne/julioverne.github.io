
//https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API/Writing_WebSocket_client_applications


var _webSocket = null;

function commandFromMessage(message){
    var columnIndex = message.indexOf(":");
    if(columnIndex===-1){
        return null;
    }
    return message.substring(0,columnIndex);
}

function dataFromMessage(message){
    var columnIndex = message.indexOf(":");
    if(columnIndex===-1){
        return null;
    }
    return message.substring(columnIndex+1);
}

var jsonObjFromMessageData = function (data){
    var obj = JSON.parse(data);
    return obj;
};

function processWebCommand(command,data){
    if(command==="SERVER_DID_STOP"){
        var obj = jsonObjFromMessageData(data);
        var url = obj.url;
        _open_url_on_server_did_stop = url;
        openURLOnServerDidStop();
    }
    else if(command==="OPEN_URL"){
        var obj = jsonObjFromMessageData(data);
        var url = obj.url;
        window.location = url;
    }
    else if(command==="CONNECTION_REJECTED"){
        hidePinCodeModal();
        showNetworkDownModal();
        showConnectionClosed();
    }
    else if(command==="ARCHIVE_PROGRESS"){
        archiveOperationChangedProgress(data);
    }
    else if(command==="ARCHIVE_DONE"){
        archiveOperationCompleted(data,true);
    }  
    else if(command==="ARCHIVE_START"){
        archiveOperationStarted(data);
    }
    else if(command==="ARCHIVE_ERROR"){
        archiveOperationCompleted(data,false);
    }
    else if(command==="DELETE_PROGRESS"){
        deleteOperationChangedProgress(data);
    }
    else if(command==="DELETE_DONE"){
        deleteOperationCompleted(data,true);
    }  
    else if(command==="DELETE_START"){
        deleteOperationStarted(data);
    }
    else if(command==="DELETE_ERROR"){
        deleteOperationCompleted(data,false);
    }
    else if(command==="SERVER_DID_SUSPEND"){
        var obj = jsonObjFromMessageData(data);
        var timeout = obj.timeout;
        var url = obj.url;
        _open_url_on_server_did_stop = url;
        showNetworkDownModalWithTimeout(timeout);
    }
    else if(command==="SERVER_DID_RESUME"){
        hideNetworkDownModal();
    }
    else if(command==="PING_CLIENT"){
        sendWebCommand("CLIENT_OK");
    }
    else if(command==="SERVER_OPEN_PATH"){
        var obj = jsonObjFromMessageData(data);
        var path = obj.path;
        if(path!==null){
            reloadWithPath(path);
        }
    }
}

function sendWebCommandAndData(command,data){
    if(_webSocket!==null){
        _webSocket.send("" + command + ":" + data);
    }
}

function sendWebCommand(command){
    sendWebCommandAndData(command,null);
}

function updateWebSocketIfNull() {
    if(_webSocket===null){
        updateWebSocket();   
    }
}

function updateWebSocket() {
    
	return;
	
    try {
        if(_webSocket!==null){
            _webSocket.close();
        }
    }
    catch(error) {
      log.log("web socket close error: " + error);
    }

    _webSocket = null;

    if ("WebSocket" in window){

        $.ajax({
           cache: false,
            url: 'rdwifidrive/web_socket_url',
            type: 'GET',
            beforeSend: function(request) {
                request.setRequestHeader("Session-Id", getSID());
            },
            dataType: 'json'
        }).fail(function (jqXHR, textStatus, errorThrown) {
            log.log("failed to get web socket url");
        }).done(function (data, textStatus, jqXHR) {
            if(data.url!==null){
                var socketURL = data.url;

                _webSocket = new WebSocket(socketURL);

                _webSocket.onopen = function(){
                    log.log("websocket is open");
                };

                _webSocket.onmessage = function(evt) { 
                    var command = commandFromMessage(evt.data);
                    var data = dataFromMessage(evt.data);
                    log.log("websocket received command: " + command + " data: " + data); 
                    processWebCommand(command,data);
                };

                _webSocket.onclose = function() {
                    log.log("websocket is closed");
                    updateWebSocket();
                };

            }
        });  
                
    }

}
